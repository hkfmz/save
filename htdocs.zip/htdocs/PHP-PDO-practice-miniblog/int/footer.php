    <!-- footer -->
    <footer>
      <a href="#"  target="_blank" >Hegel MOTOKOUA</a>
    </footer>
    </div>
  </body>
</html>