    <!-- footer -->
    <footer>
      <a href="https://#/"  target="_blank" >Hegel Khaled Fredrish Motokoua Z.</a>
    </footer>
    </div>
  </body>
</html>