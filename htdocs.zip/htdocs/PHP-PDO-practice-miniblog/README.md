# PHP-PDO-practice-miniblog
### Utilise PHP, mySql, PDO, html, css
[miniblog](http://42.tsuifei.com/miniblog/)
