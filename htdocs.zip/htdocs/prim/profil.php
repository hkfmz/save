<?php
session_start();

$bdd=new PDO('mysql:host=localhost;dbname=espace_membre','root','');

if(isset($_GET['id']) AND $_GET['id'] > 0)
{
 
  $getid= intval($_GET['id']);

  $requser=$bdd->prepare('SELECT * FROM membres WHERE id=?');

  $requser->execute(array($getid));

  $userinfos=$requser->fetch();
  
?>

<!DOCTYPE html>
<html>
<head>
  <title>Formulaire</title>
</head>
<body style="zoom: 150%;">

   <div align="center">

    <h2>Bienvenue <?php echo $userinfos['pseudo'] ?></h2>
     <br>
     <table style="border: 0.5px solid #ccc">
       <tr align="right">
         <td style="border: 0.5px solid #ccc"><label>Pseudo:</label></td>


         <td style="border: 0.5px solid #ccc; width: 200px;" align="left"><?php echo $userinfos['pseudo'] ?></td>


       </tr>

       <tr align="right">
         <td style="border: 0.5px solid #ccc">
            <label>Mail:</label>
         </td>


         <td style="border: 0.5px solid #ccc; width: 200px;" align="left"><?php echo $userinfos['mail'] ?></td>



       </tr>
     </table>
<br><br>

             <?php
                   if( isset($_SESSION['id']) AND $userinfos['id'] == $_SESSION['id'])
                   {

                   ?>
                         <a href="#"> Editer profil </a> <br>
                         <a href="deconnexion.php"> Se deconnecter </a>
                   <?php

                   }else
                   {
                       header('location: profil.php?id='.$_SESSION['id']);
                   }     
             ?>
              
   </div>
</body>
</html>

<?php

}

?>