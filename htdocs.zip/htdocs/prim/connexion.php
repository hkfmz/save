<?php
session_start();

$bdd=new PDO('mysql:host=localhost;dbname=espace_membre','root','');

//
if(isset($_POST['formconnexion']))
{
      $mailconnet=htmlspecialchars($_POST['mailconnet']);
      $mdpconnect=sha1($_POST['mdpconnect']);
      $mdpconnect=sha1($mdpconnect);

      if(!empty($_POST['mailconnet']) AND !empty($_POST['mdpconnect']))
      {
           $requser=$bdd->prepare('SELECT * FROM membres WHERE mail = ? AND motdepasse = ?');
           $requser->execute(array($mailconnet, $mdpconnect));

           $userexist=$requser->rowCount();

           if($userexist == 1)
           {
              $userinfos=$requser->fetch();
              $_SESSION['id']=$userinfos['id'];
              $_SESSION['pseudo']=$userinfos['pseudo'];
              $_SESSION['mail']=$userinfos['mail'];

              header('location: profil.php?id='.$userinfos['id']);
           }
           else{
             header("location: connexion.php");
           }
      }else
      {
        $erreur="Tous les champs doivent être renseigner !";
      }
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Formulaire</title>
</head>
<body style="zoom: 150%;">
   <div align="center">
    <h2>Connexion</h2>
     <br><br>
     <form method="POST" action="" >

        <input type="email" name="mailconnet"  placeholder="Renseigner un mail">
        <input type="password" name="mdpconnect" placeholder="Mot de passe">
        <input type="submit" name="formconnexion" value="Se connecter">
               
     </form>
<br>
    <?php if(isset($erreur))
     
     {

      echo $erreur;
     }
     
     ?>

   </div>
</body>
</html>