<?php

header("location: page/accueil.php");

?>