<!DOCTYPE html>
<html>
<head>
	<title>Blog-Hegel</title>
	<meta charset="utf-8">

<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<style>
body,h1,h2,h3,h4,h5 {font-family: "Raleway", sans-serif}
</style> 
</head>
<body>

    <div>
      
      <header style="background-color: #302c44;" class="w3-container w3-center w3-padding-32">
              <h1 style="color: #fff">BLOGGINGS</h1>
      </header>
       

<article class="w3-card-4 w3-margin w3-white">

<div class="w3-container">
	<h2>
		News: Fin du Covid-19
	</h2>
		<time>
		01 juin 2020
	    </time>
</div>

<div class="w3-container">
		<p> 
		Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
		tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
		quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
		consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
		cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
		proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
		</p>
</div>

</article>

    
    </div>
</body>
</html>
<!--<div style="width:50%; margin: 0 auto;" > 
         <img src="" alt="image" style="width:100%">
 </div>-->