<?php
 
 $bdd=new pdo("mysql:host=localhost;dbname=monblog;charset=utf8","root","");

 function ajout($titre, $contenu)
 {
 	 $bdd=new pdo("mysql:host=localhost;dbname=monblog;charset=utf8","root","");

    $req=$bdd->prepare("INSERT INTO article (titre,date,contenu) value(?,NOW(),?) ");

    $req->execute(array($titre, $contenu));
    
    $req->closeCursor();
 }

  function affiche()
 {
 	 $bdd=new pdo("mysql:host=localhost;dbname=monblog;charset=utf8","root","");

    $req= $bdd->prepare('SELECT * FROM article ORDER BY id DESC');

	 	$req->execute();

	 	$data = $req->fetchAll(PDO::FETCH_OBJ);

	 	return $data;

	 	$req->closeCursor();
 }

if (isset($_POST['valider'])) 
{
	
	$titre=$_POST['titre'];
	$contenu=$_POST['contenu'];

  if(isset($titre) AND isset($contenu))
  {
  	ajout($titre, $contenu);

  	echo "<script type='text/javascript'>alert('Ajouter avec succès !'); </script>";
  }
  else{
  	echo "<script type='text/javascript'>alert('Non Ajouter !'); </script>";
  }

}

$affiche=affiche();


?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
</head>
<body>


	<div>
	<header style="background-color: #302c44;" class="w3-container w3-center w3-padding-32">
              <h2 style="color: #fff">DASHBOARD</h2>
      </header>
	</div>

	  <h3 style="text-align: center; text-decoration: underline;" >GESTION D'ARTICLES</h3><br>

      <div class="list" >
      	<ul class="artcles" >
            <?php foreach($affiche as $valeur) : ?>

      		<li style="border: 1px solid #ccc; height: 50px; width: 90%; margin: 0 auto;" ><?= $valeur->titre ?></li><br>

      		<?php endforeach; ?>    		
     	</ul>
      </div>

      <div class="w3-container" >
      	
        <form class="w3-card-4 w3-margin w3-white" method="post">
        	<h4>Titre</h4>
        	<input type="title" name="titre">
        	<br>
        	<h4>Contenus</h4>
        	<textarea rows="10" cols="50" name="contenu"></textarea><br>

        	<input type="submit" name="valider" value="Valider">
        </form>

      </div>

</body>
</html>