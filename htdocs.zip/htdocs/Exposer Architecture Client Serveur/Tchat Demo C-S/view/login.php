<div class="login-area">
    <form class="form-inline login">
        <div class="form-group">
            <label class="form-control-static">Name: </label>
        </div>
        <div class="form-group">
            <input type="text" class="form-control" name="userName">
        </div>
        <button type="submit" class="btn btn-default submit">Login</button>
    </form>
    <div class="form-group error">login</div>
</div>
<script src="js/login.js"></script>

<!--By Hegel Motokoua-->