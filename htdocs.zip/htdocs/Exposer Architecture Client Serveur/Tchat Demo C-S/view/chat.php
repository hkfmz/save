<div class="box">
    <div class="show-chat">
        <i>Loading chat...</i>
    </div>
    <form action="#" class="chat">
        <div class="row send-chat" style="padding:15px">
            <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 box-label">Type Message</div>
            <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                <div class="form-group">
                    <!--<textarea required name="message" no-resize class="form-control message" rows="2" cols="*" placeholder="enter text here">
                        </textarea>-->
                    <input type="text" name="message" class="form-control message" />
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
                <input type="submit" value="send" class="btn btn-default submit" />
            </div>
        </div>
    </form>
</div>
<a href="exit.php">Exit</a>
<script src="js/chat.js"></script>

<!--By Hegel Motokoua-->