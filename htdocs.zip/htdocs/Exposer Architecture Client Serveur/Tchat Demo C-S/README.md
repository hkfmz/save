# simple-chat-server-using-php-mysql

Mini Tp avec PHP. Il s'agit d'un serveur de discussion simple, tout comme Yahoo Messenger. toutes les personnes peuvent discuter en groupe. Le chat sera mis à jour automatiquement.

Coder par 🌿🌿🌿 {--Hegel Motokoua--} 🌿🌿🌿 

------------------------------


Page Facabook -: https://www.facebook.com/appEnligne/
<br />
Sur youtube -: https://www.youtube.com/channel/UCpF8HCFJADce_5Iyfbjudbw

<div class="file-header">
<img src="https://zupimages.net/up/19/48/7or1.png" alt="simple-chat-server-using-php-mysql-: m.zeloumanekhaled@gmail.com"  />
</div>


<img style="border: 2px solid whitesmoke; margin-top:90px" src="#" alt="simple-chat-server-using-php-mysql-: m.zeloumanekhaled@gmail.com"  />



------------------------------
