<?php
session_start();

$bdd=new PDO('mysql:host=localhost;dbname=gestion','root','');
?>
<html>
<body>
<?php
include('cadre.php');
?>
<div class="corp">
</div>
</body>
</html>
