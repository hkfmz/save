# blog-mvc

##Ce code montre comment créer un blog en PHP avec l'architecture MVC

###Comment l'utiliser ?

- créer une base de données locale "blog_mvc"
- cloner le dépôt dans votre dossier www si vous avez wamp. Si vous n'avez pas wamp, clonez le dépôt dans le dossier des projets de votre environnement de serveur local.
- rdv dans le fichier Model.php situé dans le dossier models et modifiez les identifiants de connexion à la bdd
- enfin ouvrez votre navigateur et lancez localhost/blog_mvc
