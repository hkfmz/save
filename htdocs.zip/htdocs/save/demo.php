<?php

/** php : Fonctions  */

/* $var=readline('Entrer une chaîne de caractère: ');

$palindrome=strrev($var);

if( strtolower($var)===strtolower($palindrome ) )
{
    echo "C'est un palindrome !";
}else{
    echo "Ce n'est pas un palindrome !";
}
 */

/* echo "\n";

$notes=[16, 18, 20, 14, 13];

print_r($notes);

$moy= (float) array_sum($notes)/count($notes);

 echo "\n\n"; 
 echo "la moyenne est : $moy";

 echo "\n\n";
 */

 echo "\n\n";

    

$insultes=['merde','con','idiot','laide'];

$phrase=readline('Entrer une phrase : ');

//$etoile=['','*','**','***','****','*****','******','*******','********','**********'];

foreach($insultes as $insulte)
{

    $tailleIns=strlen($insulte);
    $preL=substr($insulte,0,-($tailleIns-1));

    $star=str_repeat('*',$tailleIns-1);
    
    $modIns=$preL.''.$star;

    $phrase=str_replace($insulte,$modIns,$phrase); 

}

// - Suppression d'un message contenant au moins une insulte
// - detection de caractère majuscule et message d'attention pas de maj.

echo $phrase;