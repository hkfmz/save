<?php 

echo "\n\n";

$insulteTab=['connard','laide','idiot','bête','impoli','merde','imbecile','ignorant','connasse','stupide'];

print_r($insulteTab);

echo "\n";

$phrase=readline('Donne une phrase:');

foreach ($insulteTab as $insulte) 
{
	$insulteSize=  strlen($insulte);

	$premiereLettreInsulte= substr($insulte,0,-($insulteSize-1));

	$star= str_repeat('*', $insulteSize-1);

	$insulteModifier= $premiereLettreInsulte."".$star;

	$phrase= str_replace($insulte, $insulteModifier, $phrase);

}
echo "\n";

echo "$phrase";

echo "\n\n";


