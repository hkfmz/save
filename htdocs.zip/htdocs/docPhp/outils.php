<?php

function repondre_oui_ou_non()
{
    $resultat=readline('voulez vous ajouter un creneau ? (o/n):');
    
    while (true)
    {
        if($resultat === 'o')
        {  
            break;
        }
        elseif($resultat === 'n')
        {
            break;
        }
        else
        {
            $resultat=readline('voulez vous ajouter un creneau ? (o/n):');
        }
    }
    
    if($resultat === 'o')
        {
            return true;
            
        } 
        elseif($resultat === 'n')
        {
            return false;
        }
}

function demander_creneau($titre='Veillez ajouter un creneau')
{
    echo "$titre \n\n";

    while(true)
    {
        $debut=readline('donner heure de debut : ');
        echo "\n";
        
        $fin=readline('donner heure de fin : ');
        echo "\n";
    
        if($debut >= $fin && $fin <= $debut)
        {
            $debut=readline('donner heure de debut : ');
            echo "\n";
    
            $fin=readline('donner heure de fin : ');
            echo "\n";
        }else
        {
            $creneaux[]=[$debut,$fin];
            $answer=repondre_oui_ou_non();
        }
    
        if($answer === false)
        {
           break;
        }
    }

    return $creneaux;
}