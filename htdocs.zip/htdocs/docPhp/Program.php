<?php 
echo "\n\n";
$tabInsultes=['merde','connard','pétasse'];//'con';
$caseInsulte=null;
print_r($tabInsultes); echo "\n";
 $phrase= (string) readline('Donnez une phrase: '); // "con est le meilleur langage de script du web.";
for($i=0; $i<sizeof($tabInsultes); $i++) {$value=$tabInsultes[$i];if(preg_match("/$value/i", $phrase)){$caseInsulte=$value;}}if($caseInsulte===$tabInsultes[0] || $caseInsulte===$tabInsultes[1] || $caseInsulte===$tabInsultes[2]){
   echo "\nIl y'a $caseInsulte comme insulte \n\n"; }else{ $caseInsulte='rien';echo "\nIl n y'a $caseInsulte comme insulte\n\n";} 