<!DOCTYPE html>
<html>
<head>
	<title>Page</title>

</head>
<body>
   <header style="margin: 0 auto; background-color: #302c44; height: 100px; width: 1000px; text-align: center" >
<h1 style="display: inline-block; color: white;">Traitement Cookie</h1>
<hr>
<hr>
<hr>

<hr>
<hr>
<hr>

   	   	    	<br><br>
   	   	    	<a href="page.php"><input type="submit" name="submit" value="Se connecter" ></a>

   </header>
    
    <div class="nav">
    	
    </div>

<footer>
	
</footer>


</body>
</html>

<?php
session_start();

try {

	$temps = 365*24*3600;

	setCookie('visite', $_COOKIE['visite'] + 1, time() + $temps);
    
}
 catch (Exception $e)
{

	echo '<h1>'.$e->getMessage().'</h1>';
}

?>