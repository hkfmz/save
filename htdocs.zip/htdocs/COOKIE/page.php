<?php
session_start();

require('fonction.php');

if (isset($_COOKIE))
{
	setCookie('visite', $_COOKIE['visite'] + 1);

echo '<h2> <mark>Vous avez visité ', $_COOKIE['visite'] + 1, ' fois ce site </mark></h2>';

$date=array(addDatex());

} 
else 
{
	
 setCookie('visite', 1); 

 echo $_SESSION['nom'];

 echo 'Vous avez visité ', $_COOKIE['visite'] + 1, ' fois ce site'; 

} 

$dates=getDatex();

?>

<!DOCTYPE html>
<html>
<head>
	<title>Visite Cookie</title>
</head>
<body>
   
    <ul>
     
    <?php foreach($dates as $valeur): ?>

    	<li><?= $valeur->date; ?></li>

     <?php endforeach ; ?>

    </ul>

</body>
</html>


