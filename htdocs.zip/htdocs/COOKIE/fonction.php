<?php
 function getDatex()
{
$bdd = new PDO('mysql:host=localhost;dbname=db_date;charset=utf8', 'root',''); 

	 $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);

    $req= $bdd->prepare('SELECT date FROM dates ORDER BY id DESC');

	 	$req->execute();

	 	$data = $req->fetchAll(PDO::FETCH_OBJ);

	 	return $data;

	 	$req->closeCursor();
 }

 function addDatex()
{
$bdd = new PDO('mysql:host=localhost;dbname=db_date;charset=utf8', 'root',''); 

	 $bdd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
 
  $req=$bdd->prepare('INSERT INTO dates (date) VALUES (NOW())');

  $req->execute();

  $req->closeCursor();
}

 ?>